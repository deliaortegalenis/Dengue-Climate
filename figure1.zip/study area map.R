#District Location Map of Madre de Dios- Peru
#Developed in R studio environment I add the R code for your script I hope it will be useful for your Sig projects with R
# Librerias
#------------------------------------------------------------------------
library(tidyverse)
library(rnaturalearth)                                   #Continentes
library(rnaturalearthdata)                               #Continentes especifico
library(sf)
library(raster)                                          # Extracion de Peru
library(reticulate)
library(maptools)
library(maps)
library(ggplot2)                                         # Graficos avanzados
library(ggspatial)                                       # Norte
#------------------------------------------------------------------------
world <- ne_countries(scale= "small", returnclass = "sf")# Continentes del mundo
world.SA <- subset(world, continent=="South America")    # Sur America
# obtener puntos centrales y coordenadas para etiquetar los nombres de los países
world_points<- st_centroid(world)                        # Centros de cada pais
world_points <- cbind(world, st_coordinates(st_centroid(world$geometry))) #Utilizamos la geometria
Sur_America  <- subset(world_points, continent == "South America")
Colombia       <- subset(Sur_America, iso_a3 == "COL")     # Seleccionamos por Pais
Col         <- getData('GADM', country= "COL",level=2) #Extracion de Colombia
Depa         <- st_read("~/Desktop/deptos/colombia_depts2.shp")          #Departamentos
Dis          <- st_read("~/Desktop/delia/SUDAMERICA_ADM2/valle.shp")              # Distritos de Madre de Dios
Marco_Per = st_as_sfc(st_bbox(Colombia))
#------------------------------------------------------------------------
#                          COLORES A DISPOSICION                       
library(colorspace) #https://awesomeopensource.com/.../EmilHv.../r-color-palettes
hcl_palettes(plot = TRUE)
q4 <- qualitative_hcl(4, palette = "Dark 3")
library(ghibli)
par(mfrow=c(9,3))
for(i in names(ghibli_palettes)) print(ghibli_palette(i))
col <- ghibli_palettes$PonyoLight
library(cartography) #https://awesomeopensource.com/.../EmilHv.../r-color-palettes
col1 = carto.pal(pal1 = "pastel.pal", n1 = 20)
#------------------------------------------------------------------------
#                                       Grafico Continental
P1 <- ggplot() +
  geom_sf(data = Sur_America, fill= "gray80", lwd=0.4, color="white",alpha = 1, linetype = 1)+
  geom_sf(data = Marco_Per, fill = NA, color = 'black', size = 1.2)+
  geom_sf(data=Depa, fill="gray60", color=NA)+
  geom_text(data= Sur_America,aes(x=X, y=Y, label=admin), size = 3,
            color = "black", fontface = "bold", check_overlap = FALSE)+
  annotation_scale() +
  annotation_north_arrow(location="br",which_north="true",style=north_arrow_nautical ())+
  theme_classic()+
  labs(title = "South America", 
       subtitle="",caption="",x="Long",y="Lat",tag="A)",size=6)+
  theme(panel.grid.major = element_line(color = gray(0.8),linetype = "dashed", size = 0.5))
#                                       Grafico Nacional
P2 <- ggplot() +
  geom_sf(data = Sur_America, fill= "gray80", lwd=0.8, color="White")+
  geom_sf(data = Marco_Per, fill = NA, color = 'black', size = 1.2)+
  geom_sf(data=Depa, fill="White", color="black", linetype = 1)+
  geom_sf(data=Dis, fill="gray50", color=NA, linetype = 1)+
  geom_text(data= Sur_America,aes(x=X, y=Y, label=admin), size = 3,
            color = "black", fontface = "bold", check_overlap = FALSE)+
  annotation_scale() +
  annotation_north_arrow(location="br",which_north="true",style=north_arrow_nautical ())+
  theme_classic()+
  labs(title = "Colombia", 
       subtitle="",caption="",x="Long",y="Lat",tag="B)")+
  theme(panel.grid.major = element_line(color = gray(.5),linetype = "dashed", size = 0.5))+
  coord_sf(xlim = c(-78.990935 , -66.876326), ylim = c(-4.298187, 12.437303 ),expand = FALSE)
#                                       Grafico Distrital
P3 <- ggplot() +
  geom_sf(data = Sur_America, fill= NA, lwd=0.8, color="black")+
  geom_sf(data = Marco_Per, fill = NA, color = 'black', size = 1.2)+
  geom_sf(data=Depa, fill=NA, color="black")+
  geom_sf(data=Dis2, show.legend = T)+
  geom_text(data= Dis2,aes(x=centroid_x, y=centroid_y, label=ADM2), size = 1.5,
            color = "black", fontface = "bold", check_overlap = T)+
  annotation_scale() +
  annotation_north_arrow(location="br",which_north="true",style=north_arrow_nautical ())+
  theme_classic()+
  labs(title = "Valle del Cauca", 
       subtitle="",caption="",x="Long",y="Lat",tag="C)")+
  theme(panel.grid.major = element_line(color = gray(.5),linetype = "dashed", size = 0.5))+
  coord_sf(xlim = c(-77.53677  , -75.7098), ylim = c(3.0641 , 4.9759 ),expand = FALSE)+
  labs(color="Species",fill = "Distritos de Madre de Dios")

#-----------------------------------------------------------------------------------
#                                       Exportacion del Mapa
library(gridExtra)
B<-grid.arrange(P1,P2,P3,ncol = 3,layout_matrix = cbind(c(1,1,1), c(2,2,2), c(3,3,3)))
# Guargdar en formato PNG
ggsave("Tipo de Clima2.png",plot = B, width =  15,height = 9, dpi=900)
#-----------------------------------------------------------------------------------




###

class(Dis)

st_coordinates(Dis)

require(dplyr)


# Calculate centroids
centroids <- st_centroid(Dis)

# Extract coordinates
centroid_coords <- st_coordinates(centroids)



# Combine centroid coordinates with the original DataFrame
Dis2 <- Dis %>%
  mutate(centroid_x = centroid_coords[,1],
         centroid_y = centroid_coords[,2])

Dis2
